CREATE TABLE `profiles` (
	`user_id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`full_name` text NOT NULL,
	`phone` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
ALTER TABLE `bookings` ADD `payment_proof_key` text;--> statement-breakpoint
ALTER TABLE `bookings` ADD `payment_proof_name` text;--> statement-breakpoint
ALTER TABLE `bookings` ADD `payment_verified_at` text;