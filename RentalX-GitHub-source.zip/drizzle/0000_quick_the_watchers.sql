CREATE TABLE `bookings` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`car_id` text NOT NULL,
	`location` text NOT NULL,
	`start_date` text NOT NULL,
	`end_date` text NOT NULL,
	`full_name` text NOT NULL,
	`email` text NOT NULL,
	`phone` text NOT NULL,
	`handover` text NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`daily_rate` integer NOT NULL,
	`total` integer NOT NULL,
	`status` text DEFAULT 'Menunggu konfirmasi' NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_bookings_user_created` ON `bookings` (`user_id`,`created_at`);