CREATE TABLE `catalog_changes` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`kind` text NOT NULL,
	`category` text NOT NULL,
	`rate` integer NOT NULL,
	`image` text NOT NULL,
	`tint` text NOT NULL,
	`deleted` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
ALTER TABLE `bookings` ADD `vehicle_name` text;--> statement-breakpoint
ALTER TABLE `bookings` ADD `vehicle_kind` text;--> statement-breakpoint
ALTER TABLE `bookings` ADD `vehicle_category` text;--> statement-breakpoint
ALTER TABLE `bookings` ADD `vehicle_image` text;--> statement-breakpoint
ALTER TABLE `bookings` ADD `vehicle_tint` text;--> statement-breakpoint
ALTER TABLE `bookings` ADD `cancelled_at` text;