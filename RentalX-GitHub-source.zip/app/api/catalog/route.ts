import { getCatalog } from "../../catalog-server";
import { noStore } from "../../auth-server";

export const dynamic = "force-dynamic";

export async function GET() {
  try { return noStore({ vehicles: await getCatalog() }); }
  catch (error) { console.error("Unable to load catalog", error); return noStore({ error: "Katalog belum dapat dimuat." }, 503); }
}
