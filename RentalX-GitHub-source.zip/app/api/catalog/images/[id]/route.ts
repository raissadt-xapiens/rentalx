import { env } from "cloudflare:workers";
import { noStore } from "../../../../auth-server";

export const dynamic = "force-dynamic";
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/.test(id) || !env.BUCKET) return noStore({ error: "Gambar tidak ditemukan." }, 404);
  try {
    const object = await env.BUCKET.get("catalog/" + id);
    if (!object) return noStore({ error: "Gambar tidak ditemukan." }, 404);
    return new Response(object.body, { headers: { "Content-Type": object.httpMetadata?.contentType || "application/octet-stream", "Cache-Control": "public, max-age=31536000, immutable", "X-Content-Type-Options": "nosniff" } });
  } catch (error) { console.error("Unable to load catalog image", error); return noStore({ error: "Gambar belum dapat dimuat." }, 503); }
}
