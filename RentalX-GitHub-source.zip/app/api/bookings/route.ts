import { desc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { bookings } from "../../../db/schema";
import { rentalDays } from "../../cars";
import { getCatalog } from "../../catalog-server";
import { noStore, platformIdentity, registeredIdentity, validOrigin } from "../../auth-server";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  if (!platformIdentity(request)) return noStore({ error: "Silakan masuk untuk melihat riwayat booking." }, 401);
  try {
    const owner = await registeredIdentity(request);
    if (!owner) return noStore({ error: "Lengkapi pendaftaran untuk melihat riwayat." }, 403);
    const rows = await getDb().select().from(bookings).where(eq(bookings.userId, owner.userId)).orderBy(desc(bookings.createdAt)).limit(100);
    return noStore({ bookings: rows.map(({ paymentProofKey: _key, ...row }) => row) });
  } catch (error) {
    console.error("Unable to load bookings", error);
    return noStore({ error: "Riwayat belum dapat dimuat. Coba lagi sebentar." }, 503);
  }
}

export async function POST(request: Request) {
  if (!validOrigin(request)) return noStore({ error: "Permintaan tidak valid." }, 403);
  if (!platformIdentity(request)) return noStore({ error: "Silakan masuk untuk membuat booking." }, 401);
  let owner: Awaited<ReturnType<typeof registeredIdentity>>;
  try { owner = await registeredIdentity(request); }
  catch (error) { console.error("Unable to load profile for booking", error); return noStore({ error: "Akun belum dapat diperiksa." }, 503); }
  if (!owner) return noStore({ error: "Lengkapi pendaftaran sebelum booking." }, 403);
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; }
  catch { return noStore({ error: "Data booking tidak valid." }, 400); }

  const pick = (key: string) => typeof body[key] === "string" ? (body[key] as string).trim() : "";
  let catalog: Awaited<ReturnType<typeof getCatalog>>;
  try { catalog = await getCatalog(); }
  catch (error) { console.error("Unable to load catalog for booking", error); return noStore({ error: "Katalog belum dapat diperiksa." }, 503); }
  const car = catalog.find((item) => item.id === pick("carId"));
  const location = pick("location");
  const startDate = pick("startDate");
  const endDate = pick("endDate");
  const fullName = pick("fullName");
  const email = pick("email");
  const phone = pick("phone");
  const handover = pick("handover");
  const note = pick("note");
  const days = rentalDays(startDate, endDate);
  const today = new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Jakarta" });
  const datePattern = /^\d{4}-\d{2}-\d{2}$/;
  if (!car || !location || location.length > 100 || !datePattern.test(startDate) || !datePattern.test(endDate) || startDate < today || days < 1 || days > 30 || !fullName || fullName.length > 100 || !/^\S+@\S+\.\S+$/.test(email) || email.length > 150 || !/^[+\d() .-]{8,25}$/.test(phone) || !["showroom", "delivery"].includes(handover) || note.length > 500) {
    return noStore({ error: "Periksa kendaraan, periode sewa, dan data kontak Anda." }, 400);
  }
  const id = `RX-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  try {
    await getDb().insert(bookings).values({ id, userId: owner.userId, carId: car.id, vehicleName: car.name, vehicleKind: car.kind, vehicleCategory: car.category, vehicleImage: car.image, vehicleTint: car.tint, location, startDate, endDate, fullName, email, phone, handover, note, dailyRate: car.rate, total: car.rate * days, status: "Menunggu konfirmasi", createdAt: new Date().toISOString() });
    return noStore({ id }, 201);
  } catch (error) {
    console.error("Unable to create booking", error);
    return noStore({ error: "Booking belum tersimpan. Silakan coba lagi." }, 503);
  }
}
