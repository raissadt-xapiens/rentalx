import { env } from "cloudflare:workers";
import { and, eq, ne, sql } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { bookings } from "../../../../../db/schema";
import { isAdmin, noStore, platformIdentity, registeredIdentity, validOrigin } from "../../../../auth-server";

export const dynamic = "force-dynamic";
const MAX_BYTES = 5 * 1024 * 1024;

function formatOf(bytes: Uint8Array): { type: string; ext: string } | null {
  if (bytes.length >= 8 && [137, 80, 78, 71, 13, 10, 26, 10].every((value, index) => bytes[index] === value)) return { type: "image/png", ext: "png" };
  if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return { type: "image/jpeg", ext: "jpg" };
  if (bytes.length >= 5 && [37, 80, 68, 70, 45].every((value, index) => bytes[index] === value)) return { type: "application/pdf", ext: "pdf" };
  return null;
}
async function ownedBooking(request: Request, id: string) {
  const owner = await registeredIdentity(request);
  if (!owner) return null;
  const row = await getDb().select().from(bookings).where(and(eq(bookings.id, id), eq(bookings.userId, owner.userId))).get();
  return row ? { owner, row } : null;
}

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!validOrigin(request)) return noStore({ error: "Permintaan tidak valid." }, 403);
  if (!platformIdentity(request)) return noStore({ error: "Silakan masuk terlebih dahulu." }, 401);
  if (!env.BUCKET) return noStore({ error: "Penyimpanan bukti pembayaran belum tersedia." }, 503);
  const { id } = await params;
  let owned: Awaited<ReturnType<typeof ownedBooking>>;
  try { owned = await ownedBooking(request, id); }
  catch (error) { console.error("Unable to load booking for payment", error); return noStore({ error: "Booking belum dapat diperiksa." }, 503); }
  if (!owned) return noStore({ error: "Booking tidak ditemukan atau akun belum terdaftar." }, 404);
  if (owned.row.status === "Dibatalkan") return noStore({ error: "Booking yang dibatalkan tidak dapat menerima pembayaran." }, 409);

  let form: FormData;
  try { form = await request.formData(); }
  catch { return noStore({ error: "Unggah berkas yang valid." }, 400); }
  const proof = form.get("proof");
  if (!(proof instanceof File) || proof.size < 1 || proof.size > MAX_BYTES) return noStore({ error: "Pilih bukti pembayaran maksimal 5 MB." }, 400);
  const bytes = new Uint8Array(await proof.arrayBuffer());
  const format = formatOf(bytes);
  if (!format) return noStore({ error: "Bukti harus berupa PNG, JPG, atau PDF." }, 400);
  const key = "payments/" + owned.owner.userId + "/" + id + "/" + crypto.randomUUID() + "." + format.ext;
  try {
    await env.BUCKET.put(key, bytes, { httpMetadata: { contentType: format.type } });
    const updated = await getDb().update(bookings).set({
      paymentProofKey: key,
      paymentProofName: proof.name.slice(0, 120),
      paymentVerifiedAt: new Date().toISOString(),
      status: sql`CASE WHEN ${bookings.status} = 'Dikonfirmasi' THEN 'Dikonfirmasi' ELSE 'Pembayaran terverifikasi' END`,
    }).where(and(eq(bookings.id, id), eq(bookings.userId, owned.owner.userId), ne(bookings.status, "Dibatalkan"))).returning({ id: bookings.id });
    if (!updated.length) { await env.BUCKET.delete(key); return noStore({ error: "Booking telah dibatalkan." }, 409); }
    if (owned.row.paymentProofKey) await env.BUCKET.delete(owned.row.paymentProofKey).catch((error) => console.error("Unable to remove old proof", error));
    return noStore({ verified: true });
  } catch (error) {
    console.error("Unable to save payment proof", error);
    await env.BUCKET.delete(key).catch(() => {});
    return noStore({ error: "Bukti pembayaran belum tersimpan. Silakan coba lagi." }, 503);
  }
}

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!platformIdentity(request)) return noStore({ error: "Silakan masuk terlebih dahulu." }, 401);
  if (!env.BUCKET) return noStore({ error: "Berkas belum tersedia." }, 503);
  const { id } = await params;
  try {
    const owned = await ownedBooking(request, id);
    const adminRow = !owned && isAdmin(request) ? await getDb().select().from(bookings).where(eq(bookings.id, id)).get() : null;
    const key = owned?.row.paymentProofKey ?? adminRow?.paymentProofKey;
    if (!key) return noStore({ error: "Bukti pembayaran tidak ditemukan." }, 404);
    const object = await env.BUCKET.get(key);
    if (!object) return noStore({ error: "Bukti pembayaran tidak ditemukan." }, 404);
    return new Response(object.body, { headers: {
      "Content-Type": object.httpMetadata?.contentType || "application/octet-stream",
      "Content-Disposition": "inline",
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    } });
  } catch (error) {
    console.error("Unable to load payment proof", error);
    return noStore({ error: "Bukti pembayaran belum dapat dibuka." }, 503);
  }
}
