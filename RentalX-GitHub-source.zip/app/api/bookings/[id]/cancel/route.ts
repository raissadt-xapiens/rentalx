import { and, eq, ne } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { bookings } from "../../../../../db/schema";
import { noStore, platformIdentity, registeredIdentity, validOrigin } from "../../../../auth-server";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!validOrigin(request)) return noStore({ error: "Permintaan tidak valid." }, 403);
  if (!platformIdentity(request)) return noStore({ error: "Silakan masuk dahulu." }, 401);
  const { id } = await params;
  try {
    const owner = await registeredIdentity(request);
    if (!owner) return noStore({ error: "Akun belum terdaftar." }, 403);
    const row = await getDb().select().from(bookings).where(and(eq(bookings.id, id), eq(bookings.userId, owner.userId))).get();
    if (!row) return noStore({ error: "Booking tidak ditemukan." }, 404);
    if (row.status === "Dibatalkan") return noStore({ error: "Booking sudah dibatalkan." }, 409);
    const updated = await getDb().update(bookings).set({ status: "Dibatalkan", cancelledAt: new Date().toISOString() })
      .where(and(eq(bookings.id, id), eq(bookings.userId, owner.userId), ne(bookings.status, "Dibatalkan"))).returning({ id: bookings.id });
    if (!updated.length) return noStore({ error: "Booking sudah dibatalkan." }, 409);
    return noStore({ status: "Dibatalkan" });
  } catch (error) { console.error("Unable to cancel booking", error); return noStore({ error: "Booking belum dapat dibatalkan." }, 503); }
}
