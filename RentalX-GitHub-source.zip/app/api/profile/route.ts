import { getDb } from "../../../db";
import { profiles } from "../../../db/schema";
import { noStore, platformIdentity, validOrigin } from "../../auth-server";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!validOrigin(request)) return noStore({ error: "Permintaan tidak valid." }, 403);
  const identity = platformIdentity(request);
  if (!identity) return noStore({ error: "Silakan masuk terlebih dahulu." }, 401);
  let body: { fullName?: unknown; phone?: unknown };
  try { body = await request.json() as { fullName?: unknown; phone?: unknown }; }
  catch { return noStore({ error: "Data profil tidak valid." }, 400); }
  const fullName = typeof body.fullName === "string" ? body.fullName.trim() : "";
  const phone = typeof body.phone === "string" ? body.phone.trim() : "";
  if (fullName.length < 2 || fullName.length > 100 || !/^[+\d() .-]{8,25}$/.test(phone)) {
    return noStore({ error: "Isi nama dan nomor telepon yang valid." }, 400);
  }
  try {
    await getDb().insert(profiles).values({
      userId: identity.userId, email: identity.email, fullName, phone, createdAt: new Date().toISOString(),
    }).onConflictDoUpdate({ target: profiles.userId, set: { email: identity.email, fullName, phone } });
    return noStore({ registered: true, user: { email: identity.email, fullName, phone } });
  } catch (error) {
    console.error("Unable to save profile", error);
    return noStore({ error: "Profil belum tersimpan. Coba lagi." }, 503);
  }
}
