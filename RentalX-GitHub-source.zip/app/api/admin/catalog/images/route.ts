import { env } from "cloudflare:workers";
import { noStore, requireAdmin, validOrigin } from "../../../../auth-server";

export const dynamic = "force-dynamic";
const MAX_BYTES = 5 * 1024 * 1024;

export async function POST(request: Request) {
  const forbidden = requireAdmin(request);
  if (forbidden) return forbidden;
  if (!validOrigin(request)) return noStore({ error: "Permintaan tidak valid." }, 403);
  if (!env.BUCKET) return noStore({ error: "Penyimpanan gambar belum tersedia." }, 503);
  const form = await request.formData().catch(() => null);
  const file = form?.get("image");
  if (!(file instanceof File) || file.size < 1 || file.size > MAX_BYTES) return noStore({ error: "Pilih PNG, JPG, atau WebP maksimal 5 MB." }, 400);
  const bytes = new Uint8Array(await file.arrayBuffer());
  const png = [137, 80, 78, 71, 13, 10, 26, 10].every((part, index) => bytes[index] === part);
  const jpeg = bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
  const webp = new TextDecoder().decode(bytes.slice(0, 4)) === "RIFF" && new TextDecoder().decode(bytes.slice(8, 12)) === "WEBP";
  const type = png ? "image/png" : jpeg ? "image/jpeg" : webp ? "image/webp" : null;
  if (!type) return noStore({ error: "Format gambar harus PNG, JPG, atau WebP." }, 400);
  const id = crypto.randomUUID();
  try {
    await env.BUCKET.put("catalog/" + id, bytes, { httpMetadata: { contentType: type } });
    return noStore({ image: "/api/catalog/images/" + id }, 201);
  } catch (error) { console.error("Unable to upload catalog image", error); return noStore({ error: "Gambar belum dapat diunggah." }, 503); }
}
