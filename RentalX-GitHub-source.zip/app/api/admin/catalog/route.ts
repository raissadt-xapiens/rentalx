import { eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { catalogChanges } from "../../../../db/schema";
import { carCategories, motorCategories, vehicles, type VehicleKind } from "../../../cars";
import { getCatalog } from "../../../catalog-server";
import { noStore, requireAdmin, validOrigin } from "../../../auth-server";

export const dynamic = "force-dynamic";

function parseVehicle(body: Record<string, unknown>) {
  const name = typeof body.name === "string" ? body.name.trim() : "";
  const kind = body.kind;
  const category = body.category;
  const rate = body.rate;
  const image = typeof body.image === "string" ? body.image.trim() : "";
  const tint = typeof body.tint === "string" ? body.tint.trim() : "";
  if (name.length < 2 || name.length > 100 || (kind !== "mobil" && kind !== "motor") ||
    typeof category !== "string" || !(kind === "mobil" ? carCategories : motorCategories).slice(1).includes(category) ||
    !Number.isInteger(rate) || (rate as number) < 10000 || (rate as number) > 10000000 ||
    !(/^(\/images\/[a-zA-Z0-9._-]+\.png)$/.test(image) || /^\/api\/catalog\/images\/[0-9a-f-]{36}$/.test(image)) ||
    !/^#[0-9a-fA-F]{6}$/.test(tint)) return null;
  return { name, kind: kind as VehicleKind, category, rate: rate as number, image, tint };
}

export async function GET(request: Request) {
  const forbidden = requireAdmin(request);
  if (forbidden) return forbidden;
  try { return noStore({ vehicles: await getCatalog() }); }
  catch (error) { console.error("Unable to load admin catalog", error); return noStore({ error: "Katalog belum dapat dimuat." }, 503); }
}

export async function POST(request: Request) {
  const forbidden = requireAdmin(request);
  if (forbidden) return forbidden;
  if (!validOrigin(request)) return noStore({ error: "Permintaan tidak valid." }, 403);
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; }
  catch { return noStore({ error: "Data kendaraan tidak valid." }, 400); }
  const vehicle = parseVehicle(body);
  if (!vehicle) return noStore({ error: "Lengkapi nama, kategori, tarif, gambar, dan warna yang valid." }, 400);
  const id = "custom-" + crypto.randomUUID();
  const now = new Date().toISOString();
  try {
    await getDb().insert(catalogChanges).values({ id, ...vehicle, createdAt: now, updatedAt: now });
    return noStore({ id }, 201);
  } catch (error) { console.error("Unable to create catalog item", error); return noStore({ error: "Kendaraan belum dapat ditambahkan." }, 503); }
}

export async function PATCH(request: Request) {
  const forbidden = requireAdmin(request);
  if (forbidden) return forbidden;
  if (!validOrigin(request)) return noStore({ error: "Permintaan tidak valid." }, 403);
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; }
  catch { return noStore({ error: "Data kendaraan tidak valid." }, 400); }
  const id = typeof body.id === "string" ? body.id : "";
  const vehicle = parseVehicle(body);
  if (!vehicle) return noStore({ error: "Lengkapi nama, kategori, tarif, gambar, dan warna yang valid." }, 400);
  try {
    const old = await getDb().select().from(catalogChanges).where(eq(catalogChanges.id, id)).get();
    if (old?.deleted || (!old && !vehicles.some((item) => item.id === id))) return noStore({ error: "Kendaraan tidak ditemukan." }, 404);
    const now = new Date().toISOString();
    await getDb().insert(catalogChanges).values({ id, ...vehicle, createdAt: old?.createdAt || now, updatedAt: now })
      .onConflictDoUpdate({ target: catalogChanges.id, set: { ...vehicle, updatedAt: now } });
    return noStore({ id });
  } catch (error) { console.error("Unable to update catalog item", error); return noStore({ error: "Perubahan kendaraan belum tersimpan." }, 503); }
}

export async function DELETE(request: Request) {
  const forbidden = requireAdmin(request);
  if (forbidden) return forbidden;
  if (!validOrigin(request)) return noStore({ error: "Permintaan tidak valid." }, 403);
  let body: { id?: unknown };
  try { body = await request.json() as { id?: unknown }; }
  catch { return noStore({ error: "Kendaraan tidak valid." }, 400); }
  const id = typeof body.id === "string" ? body.id : "";
  try {
    const old = await getDb().select().from(catalogChanges).where(eq(catalogChanges.id, id)).get();
    const original = vehicles.find((item) => item.id === id);
    if (old?.deleted || (!old && !original)) return noStore({ error: "Kendaraan tidak ditemukan." }, 404);
    const now = new Date().toISOString();
    if (old) await getDb().update(catalogChanges).set({ deleted: 1, updatedAt: now }).where(eq(catalogChanges.id, id));
    else if (original) await getDb().insert(catalogChanges).values({ id, name: original.name, kind: original.kind, category: original.category, rate: original.rate, image: original.image, tint: original.tint, deleted: 1, createdAt: now, updatedAt: now });
    return noStore({ id, deleted: true });
  } catch (error) { console.error("Unable to delete catalog item", error); return noStore({ error: "Kendaraan belum dapat dihapus." }, 503); }
}
