import { and, eq, notInArray } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { bookings } from "../../../../../db/schema";
import { noStore, requireAdmin, validOrigin } from "../../../../auth-server";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const forbidden = requireAdmin(request);
  if (forbidden) return forbidden;
  if (!validOrigin(request)) return noStore({ error: "Permintaan tidak valid." }, 403);
  const { id } = await params;
  try {
    const updated = await getDb().update(bookings).set({ status: "Dikonfirmasi" })
      .where(and(eq(bookings.id, id), notInArray(bookings.status, ["Dibatalkan", "Dikonfirmasi"]))).returning({ id: bookings.id });
    if (!updated.length) return noStore({ error: "Booking tidak ditemukan atau sudah dibatalkan." }, 409);
    return noStore({ id, status: "Dikonfirmasi" });
  } catch (error) { console.error("Unable to confirm booking", error); return noStore({ error: "Booking belum dapat dikonfirmasi." }, 503); }
}
