import { desc } from "drizzle-orm";
import { getDb } from "../../../../db";
import { bookings } from "../../../../db/schema";
import { noStore, requireAdmin } from "../../../auth-server";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const forbidden = requireAdmin(request);
  if (forbidden) return forbidden;
  try {
    const rows = await getDb().select().from(bookings).orderBy(desc(bookings.createdAt)).limit(500);
    return noStore({ bookings: rows.map(({ paymentProofKey: _key, ...row }) => row) });
  } catch (error) { console.error("Unable to load admin bookings", error); return noStore({ error: "Booking belum dapat dimuat." }, 503); }
}
