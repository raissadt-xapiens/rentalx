import { eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { profiles } from "../../../../db/schema";
import { isAdmin, noStore, platformIdentity } from "../../../auth-server";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const identity = platformIdentity(request);
  if (!identity) return noStore({ authenticated: false, registered: false, isAdmin: false, user: null });
  try {
    const profile = await getDb().select().from(profiles).where(eq(profiles.userId, identity.userId)).get();
    return noStore({
      authenticated: true, registered: Boolean(profile), isAdmin: isAdmin(request),
      user: { email: identity.email, fullName: profile?.fullName ?? "", phone: profile?.phone ?? "" },
    });
  } catch (error) {
    console.error("Unable to load profile", error);
    return noStore({ error: "Status akun belum dapat dimuat." }, 503);
  }
}
