"use client";

import { CSSProperties, FormEvent, useEffect, useRef, useState, useSyncExternalStore } from "react";
import { QueryClient, QueryClientProvider, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, Outlet, RouterProvider, createRootRoute, createRoute, createRouter, useNavigate, useSearch } from "@tanstack/react-router";
import { CalendarDays, CarFront, CheckCircle2, Clock3, History, LogIn, LogOut, Mail, MapPin, Phone, Search, ShieldCheck, Ticket, UploadCloud, UserRound, X, LayoutDashboard, Pencil, Plus, Trash2 } from "lucide-react";
import { carCategories, cities, dateInput, findVehicle, motorCategories, niceDate, rentalDays, rupiah, vehicles, type Vehicle, type VehicleKind } from "./cars";
import { Sidebar, SidebarProvider } from "@/components/ui/sidebar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const read = (value: unknown) => typeof value === "string" ? value : undefined;
type SearchState = { location?: string; start?: string; end?: string; category?: string; car?: string; type?: VehicleKind };
const parseSearch = (value: Record<string, unknown>): Partial<SearchState> => ({
  location: read(value.location), start: read(value.start), end: read(value.end), category: read(value.category),
  car: read(value.car), type: value.type === "motor" ? "motor" : "mobil",
});
const parseAuthSearch = (value: Record<string, unknown>) => ({ redirect: read(value.redirect) });
type Session = { authenticated: boolean; registered: boolean; isAdmin: boolean; user: { email: string; fullName: string; phone: string } | null };
async function sessionRequest(): Promise<Session> {
  const response = await fetch("/api/auth/me", { cache: "no-store" });
  const data = await response.json() as Session & { error?: string };
  if (!response.ok) throw new Error(data.error || "Status akun belum dapat dimuat.");
  return data;
}
async function catalogRequest(): Promise<{ vehicles: Vehicle[] }> {
  const response = await fetch("/api/catalog", { cache: "no-store" });
  const data = await response.json() as { vehicles: Vehicle[]; error?: string };
  if (!response.ok) throw new Error(data.error || "Katalog belum dapat dimuat.");
  return data;
}
function safeReturn(value?: string) {
  if (!value || !value.startsWith("/") || value.startsWith("//")) return "/koleksi";
  try {
    const url = new URL(value, "https://rentalx.local");
    if (url.origin === "https://rentalx.local" && ["/booking", "/riwayat", "/koleksi", "/admin"].includes(url.pathname)) return url.pathname + url.search;
  } catch { /* gunakan halaman koleksi */ }
  return "/koleksi";
}
function bookingPath(item: Vehicle, location: string, start: string, end: string) {
  return "/booking?" + new URLSearchParams({ car: item.id, location, start, end, type: item.kind }).toString();
}
const rootRoute = createRootRoute({ component: () => <Outlet /> });
const homeRoute = createRoute({ getParentRoute: () => rootRoute, path: "/", component: HomePage });
const collectionRoute = createRoute({ getParentRoute: () => rootRoute, path: "/koleksi", validateSearch: parseSearch, component: CollectionPage });
const bookingRoute = createRoute({ getParentRoute: () => rootRoute, path: "/booking", validateSearch: parseSearch, component: BookingPage });
const historyRoute = createRoute({ getParentRoute: () => rootRoute, path: "/riwayat", component: HistoryPage });
const adminRoute = createRoute({ getParentRoute: () => rootRoute, path: "/admin", component: AdminPage });
const loginRoute = createRoute({ getParentRoute: () => rootRoute, path: "/login", validateSearch: parseAuthSearch, component: () => <AuthPage mode="login" /> });
const registerRoute = createRoute({ getParentRoute: () => rootRoute, path: "/register", validateSearch: parseAuthSearch, component: () => <AuthPage mode="register" /> });
const router = createRouter({ routeTree: rootRoute.addChildren([homeRoute, collectionRoute, bookingRoute, historyRoute, adminRoute, loginRoute, registerRoute]), defaultPreload: "intent", scrollRestoration: true });
declare module "@tanstack/react-router" { interface Register { router: typeof router } }

export default function RentalApp() {
  const ready = useSyncExternalStore(() => () => {}, () => true, () => false);
  const [queryClient] = useState(() => new QueryClient({ defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } } }));
  useEffect(() => {
    type WebTool = { name: string; title: string; description: string; inputSchema: object; annotations: { readOnlyHint: boolean; untrustedContentHint: boolean }; execute: (input: unknown) => Promise<unknown> };
    const context = (document as Document & { modelContext?: { registerTool: (tool: WebTool, options: { signal: AbortSignal }) => void | Promise<void> } }).modelContext;
    if (!context?.registerTool) return;
    const controller = new AbortController();
    const register = (tool: WebTool) => {
      try { void Promise.resolve(context.registerTool(tool, { signal: controller.signal })).catch(console.error); }
      catch (error) { console.error(error); }
    };
    register({
      name: "search_rental_vehicles", title: "Cari kendaraan sewa", description: "Cari mobil atau motor RentalX berdasarkan nama dan kategori; tarif hanya contoh.",
      inputSchema: { type: "object", properties: { query: { type: "string" }, type: { type: "string", enum: ["mobil", "motor"] }, category: { type: "string" } }, additionalProperties: false },
      annotations: { readOnlyHint: true, untrustedContentHint: false },
      async execute(input) {
        const value = (input ?? {}) as { query?: unknown; type?: unknown; category?: unknown };
        const query = typeof value.query === "string" ? value.query.toLowerCase() : "";
        const type = value.type === "motor" ? "motor" : "mobil";
        const category = typeof value.category === "string" ? value.category : "Semua";
        if (!(type === "mobil" ? carCategories : motorCategories).includes(category)) throw new Error("Kategori tidak valid.");
        const response = await fetch("/api/catalog", { cache: "no-store" });
        if (!response.ok) throw new Error("Katalog belum dapat dimuat.");
        const data = await response.json() as { vehicles: Vehicle[] };
        return { vehicles: data.vehicles.filter((item) => item.kind === type && (category === "Semua" || item.category === category) && item.name.toLowerCase().includes(query)).map(({ id, name, kind, category, rate }) => ({ id, name, kind, category, dailyRateExample: rate })) };
      },
    });
    register({
      name: "create_booking_request", title: "Kirim permintaan booking", description: "Membuat permintaan booking RentalX berstatus menunggu konfirmasi. Tidak melakukan pembayaran.",
      inputSchema: { type: "object", properties: { carId: { type: "string" }, location: { type: "string" }, startDate: { type: "string", format: "date" }, endDate: { type: "string", format: "date" }, fullName: { type: "string" }, email: { type: "string" }, phone: { type: "string" }, handover: { type: "string", enum: ["showroom", "delivery"] }, note: { type: "string" } }, required: ["carId", "location", "startDate", "endDate", "fullName", "email", "phone", "handover"], additionalProperties: false },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      async execute(input) {
        if (!input || typeof input !== "object") throw new Error("Data booking tidak valid.");
        const response = await fetch("/api/bookings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) });
        const data = await response.json() as { id?: string; error?: string };
        if (!response.ok || !data.id) throw new Error(data.error || "Booking belum tersimpan.");
        await queryClient.invalidateQueries({ queryKey: ["bookings"] });
        await router.navigate({ to: "/riwayat" });
        return { id: data.id, status: "Menunggu konfirmasi" };
      },
    });
    return () => controller.abort();
  }, [queryClient]);
  if (!ready) return <div className="app-loading"><CarFront size={28} /> RentalX</div>;
  return <QueryClientProvider client={queryClient}><RouterProvider router={router} /></QueryClientProvider>;
}

function Brand({ compact = false }: { compact?: boolean }) {
  return <Link to="/" className={compact ? "brand brand-compact" : "brand"} aria-label="RentalX, kembali ke homepage"><CarFront size={compact ? 23 : 25} strokeWidth={2.5} /><span>Rental<span className="brand-x">X</span></span></Link>;
}

function Header() {
  const session = useQuery({ queryKey: ["session"], queryFn: sessionRequest });
  return <header className="site-header"><div className="header-inner"><Brand /><nav className="main-nav" aria-label="Navigasi utama"><Link to="/" className="active">Home</Link><Link to="/koleksi" search={{}}>Koleksi</Link><Link to="/riwayat">Riwayat</Link>{session.data?.isAdmin && <Link to="/admin">Admin</Link>}</nav>{session.data?.registered ? <a className="header-cta" href="/signout-with-chatgpt?return_to=%2F">Keluar</a> : <Link to="/login" search={{ redirect: "/riwayat" }} className="header-cta">Masuk / Daftar</Link>}</div></header>;
}
function Footer() { return <footer className="site-footer"><div className="footer-inner"><Brand /><span>Sewa mobil dan motor untuk perjalanan Anda.</span><span>© RentalX 2026</span></div></footer>; }

function MobileNav({ active }: { active: "home" | "collection" | "booking" | "history" | "account" | "admin" }) {
  const session = useQuery({ queryKey: ["session"], queryFn: sessionRequest });
  return <nav className="mobile-bottom-nav" aria-label="Navigasi utama mobile">
    <Link to="/" className={active === "home" ? "rail-active" : ""} aria-label="Home"><CarFront size={20} /><span>Home</span></Link>
    <Link to="/koleksi" search={{}} className={active === "collection" ? "rail-active" : ""} aria-label="Koleksi"><Search size={20} /><span>Koleksi</span></Link>
    <Link to="/booking" search={{}} className={active === "booking" ? "rail-active" : ""} aria-label="Booking"><Ticket size={20} /><span>Booking</span></Link>
    <Link to="/riwayat" className={active === "history" ? "rail-active" : ""} aria-label="Riwayat"><History size={20} /><span>Riwayat</span></Link>
    {session.data?.isAdmin ? <Link to="/admin" className={active === "admin" ? "rail-active" : ""} aria-label="Admin"><LayoutDashboard size={20} /><span>Admin</span></Link> : session.data?.registered ? <a href="/signout-with-chatgpt?return_to=%2F" aria-label="Keluar"><LogOut size={20} /><span>Keluar</span></a> : <Link to="/login" search={{ redirect: "/riwayat" }} className={active === "account" ? "rail-active" : ""} aria-label="Masuk"><LogIn size={20} /><span>Masuk</span></Link>}
  </nav>;
}

function CitySelect({ value, onChange, className = "" }: { value: string; onChange: (value: string) => void; className?: string }) {
  return <span className={"city-select " + className}><Select value={value} onValueChange={onChange}><SelectTrigger aria-label="Kota pengambilan" className="rental-city-trigger"><SelectValue placeholder="Pilih kota" /></SelectTrigger><SelectContent position="popper" align="start" className="rental-city-options">{cities.map((city) => <SelectItem className="rental-city-option" key={city} value={city}>{city}</SelectItem>)}</SelectContent></Select></span>;
}

function AuthPage({ mode }: { mode: "login" | "register" }) {
  const search = useSearch({ strict: false }) as { redirect?: string };
  const returnTo = safeReturn(search.redirect);
  const session = useQuery({ queryKey: ["session"], queryFn: sessionRequest });
  const queryClient = useQueryClient();
  const [fullName, setFullName] = useState<string | null>(null);
  const [phone, setPhone] = useState<string | null>(null);
  const displayName = fullName ?? session.data?.user?.fullName ?? "";
  const displayPhone = phone ?? session.data?.user?.phone ?? "";
  const signInReturn = "/register?redirect=" + encodeURIComponent(returnTo);
  const signInHref = "/signin-with-chatgpt?return_to=" + encodeURIComponent(signInReturn);
  useEffect(() => {
    if (session.data?.registered) window.location.replace(returnTo);
    else if (session.data?.authenticated && mode === "login") window.location.replace("/register?redirect=" + encodeURIComponent(returnTo));
  }, [mode, returnTo, session.data?.authenticated, session.data?.registered]);
  const mutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/profile", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fullName: displayName, phone: displayPhone }) });
      const data = await response.json() as { registered?: boolean; error?: string };
      if (!response.ok || !data.registered) throw new Error(data.error || "Pendaftaran belum tersimpan.");
    },
    onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: ["session"] }); window.location.replace(returnTo); },
  });
  function submit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); mutation.mutate(); }
  return <div className="auth-page"><header className="auth-header"><Brand /><Link to="/koleksi" search={{}}>Lihat koleksi</Link></header><main className="auth-card">
    <span className="eyebrow">RENTALX ACCOUNT</span>
    <h1>{mode === "login" ? "Masuk untuk melanjutkan" : "Daftar RentalX"}</h1>
    <p className="auth-lead">{mode === "login" ? "Masuk sebelum melakukan booking atau melihat riwayat perjalanan Anda." : "Lengkapi profil agar booking dan riwayat tersimpan pada akun Anda."}</p>
    {session.isPending ? <div className="auth-loading">Memeriksa akun...</div> : session.isError ? <div className="auth-loading"><p role="alert">{session.error.message}</p><button type="button" className="dark-link" onClick={() => session.refetch()}>Coba Lagi</button></div> : session.data?.registered || (mode === "login" && session.data?.authenticated) ? <div className="auth-loading">Mengalihkan ke halaman Anda...</div> : !session.data?.authenticated ? <>
      <a className="yellow-button auth-primary" href={signInHref}><LogIn size={18} /> {mode === "login" ? "Masuk dengan ChatGPT" : "Daftar dengan ChatGPT"}</a>
      <p className="auth-help">Akun ChatGPT digunakan untuk masuk secara aman. Jika belum punya akun, Anda dapat membuatnya pada langkah berikutnya.</p>
      <div className="auth-switch">{mode === "login" ? <>Belum punya akun? <Link to="/register" search={{ redirect: returnTo }}>Daftar</Link></> : <>Sudah punya akun? <Link to="/login" search={{ redirect: returnTo }}>Masuk</Link></>}</div>
    </> : <form onSubmit={submit} className="auth-form">
      <div className="auth-email"><Mail size={17} /><span>{session.data.user?.email}</span><CheckCircle2 size={17} /></div>
      <label><span>Nama lengkap</span><input required minLength={2} maxLength={100} value={displayName} onChange={(event) => setFullName(event.target.value)} placeholder="Nama sesuai identitas" autoComplete="name" /></label>
      <label><span>Nomor telepon</span><input required minLength={8} maxLength={25} value={displayPhone} onChange={(event) => setPhone(event.target.value)} placeholder="08xxxxxxxxxx" autoComplete="tel" inputMode="tel" /></label>
      {mutation.error && <p className="form-error" role="alert">{mutation.error.message}</p>}
      <button type="submit" className="yellow-button auth-primary" disabled={mutation.isPending}>{mutation.isPending ? "Menyimpan..." : "Selesaikan Pendaftaran"}</button>
    </form>}
  </main><p className="auth-bottom">© RentalX 2026</p><MobileNav active="account" /></div>;
}

function HomePage() {
  const navigate = useNavigate();
  const [location, setLocation] = useState("Jakarta");
  const [start, setStart] = useState(() => dateInput(1));
  const [end, setEnd] = useState(() => dateInput(3));
  const [type, setType] = useState<VehicleKind>("mobil");
  const [error, setError] = useState("");
  const catalog = useQuery({ queryKey: ["catalog"], queryFn: catalogRequest });
  const featured = (catalog.data?.vehicles ?? []).filter((item) => item.kind === type).slice(0, 3);
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!location || rentalDays(start, end) < 1 || rentalDays(start, end) > 30) { setError("Pilih kota dan periode sewa antara 1–30 hari."); return; }
    setError("");
    navigate({ to: "/koleksi", search: { location, start, end, type } });
  }
  return <div className="home-page"><Header /><main>
    <section className="home-hero"><div className="hero-inner"><div className="hero-intro"><span className="eyebrow">THE JOURNEY STARTS HERE</span><h1>RENTAL MOBIL<br />& MOTOR<span className="hero-star">✳</span></h1><p>Pilih kendaraan Anda. Atur perjalanan dengan cara yang lebih mudah.</p></div>
      <form className="hero-search" onSubmit={submit}><div className="search-tabs" role="group" aria-label="Jenis kendaraan"><button type="button" aria-pressed={type === "mobil"} onClick={() => setType("mobil")} className={type === "mobil" ? "selected" : ""}>Mobil</button><button type="button" aria-pressed={type === "motor"} onClick={() => setType("motor")} className={type === "motor" ? "selected" : ""}>Motor</button></div><div className="hero-search-fields"><div className="search-field"><span>Lokasi pengambilan</span><div><MapPin size={18} /><CitySelect value={location} onChange={setLocation} /></div></div><label className="search-field"><span>Tanggal mulai</span><div><CalendarDays size={18} /><input required type="date" min={dateInput()} value={start} onChange={(event) => setStart(event.target.value)} /></div></label><label className="search-field"><span>Tanggal selesai</span><div><CalendarDays size={18} /><input required type="date" min={start} value={end} onChange={(event) => setEnd(event.target.value)} /></div></label><button className="search-submit" type="submit" aria-label="Cari kendaraan"><Search size={19} /><span>Cari</span></button></div>{error && <p className="form-error" role="alert">{error}</p>}</form>
      <div className={"hero-car-stage " + (type === "motor" ? "hero-motor-stage" : "")}><span className="hero-accent accent-one">✳</span><img src={type === "mobil" ? "/images/family-car-v2.png" : "/images/city-motor-v2.png"} alt={"Ilustrasi " + type + " sewa"} /><span className="hero-accent accent-two">✳</span></div><div className="hero-ground" /><div className="hero-index"><span>ILUSTRASI KENDARAAN</span><span>MOBIL / MOTOR</span></div></div></section>
    <section className="home-fleet"><div className="section-heading"><div><span className="eyebrow">OUR COLLECTION</span><h2>PILIH {type === "mobil" ? "MOBIL" : "MOTOR"}<br />UNTUK ANDA</h2></div><Link to="/koleksi" search={{ type }} className="dark-link">Lihat Semua {type === "mobil" ? "Mobil" : "Motor"}</Link></div>{catalog.isPending ? <p>Memuat kendaraan...</p> : catalog.isError ? <p role="alert">{catalog.error.message} <button className="admin-text-button" onClick={() => catalog.refetch()}>Coba lagi</button></p> : <div className="featured-grid">{featured.map((item) => <Link key={item.id} to="/booking" search={{ car: item.id, location, start, end, type }} className="featured-car"><div className="featured-image" style={{ background: item.tint }}><img src={item.image} alt="" />{item.illustrative && <span>Visual ilustrasi</span>}</div><div className="featured-bottom"><div><span>{item.category} · {type}</span><h3>{item.name}</h3></div><strong>{rupiah(item.rate)}<small>/hari</small></strong></div></Link>)}</div>}<p className="sample-caption">Tarif yang ditampilkan adalah contoh untuk prototipe RentalX.</p></section>
  </main><Footer /><MobileNav active="home" /></div>;
}

type RailSection = "collection" | "booking" | "history" | "admin";
function Rail({ active }: { active: RailSection }) {
  const session = useQuery({ queryKey: ["session"], queryFn: sessionRequest });
  return <Sidebar collapsible="none" className={"catalog-rail " + (session.data?.isAdmin ? "has-admin" : "")}><Brand compact /><nav aria-label="Navigasi utama"><Link to="/" title="Home" aria-label="Home"><span className="rail-icon"><CarFront size={20} /></span><span className="rail-label">Home</span></Link><Link to="/koleksi" search={{}} title="Koleksi" aria-label="Koleksi" className={active === "collection" ? "rail-active" : ""}><span className="rail-icon"><Search size={20} /></span><span className="rail-label">Koleksi</span></Link><Link to="/booking" search={{}} title="Booking" aria-label="Booking" className={active === "booking" ? "rail-active" : ""}><span className="rail-icon"><Ticket size={20} /></span><span className="rail-label">Booking</span></Link><Link to="/riwayat" title="Riwayat" aria-label="Riwayat" className={active === "history" ? "rail-active" : ""}><span className="rail-icon"><History size={20} /></span><span className="rail-label">Riwayat</span></Link>{session.data?.isAdmin && <Link to="/admin" title="Admin" aria-label="Admin" className={active === "admin" ? "rail-active" : ""}><span className="rail-icon"><LayoutDashboard size={20} /></span><span className="rail-label">Admin</span></Link>}</nav>{session.data?.registered ? <a className="rail-account" href="/signout-with-chatgpt?return_to=%2F" aria-label="Keluar" title="Keluar"><LogOut size={18} /><span className="rail-label">Keluar</span></a> : <Link to="/login" search={{ redirect: "/riwayat" }} className="rail-account" aria-label="Masuk" title="Masuk"><LogIn size={18} /><span className="rail-label">Masuk</span></Link>}</Sidebar>;
}
const shellStyle = { "--sidebar-width": "88px" } as CSSProperties;
function Workspace({ active, children, catalog = false }: { active: RailSection; children: React.ReactNode; catalog?: boolean }) {
  return <div className="workspace-page"><SidebarProvider className={"workspace-shell " + (catalog ? "catalog-shell" : "standard-shell")} style={shellStyle}><Rail active={active} />{children}</SidebarProvider></div>;
}

function VehicleCard({ item, active, onSelect }: { item: Vehicle; active: boolean; onSelect: () => void }) {
  return <button type="button" className={"car-card " + (active ? "car-card-active" : "")} onClick={onSelect} aria-pressed={active}><div className="card-head"><div><h3>{item.name}</h3><span className="card-kind">{item.kind === "mobil" ? "Mobil" : "Motor"} sewa</span></div><span className="card-category">{item.category}</span></div><div className="card-visual" style={{ backgroundColor: item.tint }}><img src={item.image} alt="" /><small>Visual ilustrasi</small></div><div className="card-foot"><span>{item.kind === "mobil" ? "Mobil" : "Motor"} · {item.category}</span><div className="card-price"><strong>{rupiah(item.rate)}</strong><small>/hari · tarif contoh</small></div></div></button>;
}

function CollectionPage() {
  const search = useSearch({ strict: false }) as Partial<SearchState>;
  const session = useQuery({ queryKey: ["session"], queryFn: sessionRequest });
  const catalog = useQuery({ queryKey: ["catalog"], queryFn: catalogRequest });
  const mainRef = useRef<HTMLElement>(null);
  const [type, setType] = useState<VehicleKind>(search.type === "motor" ? "motor" : "mobil");
  const [category, setCategory] = useState(search.category || "Semua");
  const [keyword, setKeyword] = useState("");
  const [selected, setSelected] = useState(search.car || "");
  const [page, setPage] = useState(1);
  const categories = type === "mobil" ? carCategories : motorCategories;
  const filtered = (catalog.data?.vehicles ?? []).filter((item) => item.kind === type && (category === "Semua" || item.category === category) && item.name.toLowerCase().includes(keyword.trim().toLowerCase()));
  const pageSize = 5;
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, pageCount);
  const pageItems = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);
  const activeVehicle = pageItems.find((item) => item.id === selected) ?? pageItems[0];
  const selectedIndex = activeVehicle ? filtered.indexOf(activeVehicle) + 1 : 0;
  const location = search.location && cities.includes(search.location) ? search.location : "Jakarta";
  const start = search.start || dateInput(1);
  const end = search.end || dateInput(3);

  function changeType(next: VehicleKind) {
    setType(next); setCategory("Semua"); setKeyword(""); setSelected(""); setPage(1);
    mainRef.current?.scrollTo({ top: 0 });
  }
  function changeCategory(next: string) {
    setCategory(next); setSelected(""); setPage(1);
  }
  function changeKeyword(next: string) {
    setKeyword(next); setSelected(""); setPage(1);
  }
  function changePage(next: number) {
    setPage(next); setSelected("");
    mainRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  }

  return <Workspace active="collection" catalog>
    <main className="catalog-main" ref={mainRef}>
      <div className="catalog-topline"><span className="mode-switch"><span>RentalX</span><strong>Sewa</strong></span><span className="catalog-date"><CalendarDays size={16} /> {niceDate(start)} – {niceDate(end)}</span></div>
      <div className="catalog-heading"><span className="eyebrow">RENTALX COLLECTION</span><h1>Cari {type === "mobil" ? "Mobil" : "Motor"}<span>✳</span></h1><p>Pilih kendaraan yang tepat untuk perjalanan Anda.</p></div>
      <div className="vehicle-switch" role="group" aria-label="Jenis kendaraan">
        <button type="button" aria-pressed={type === "mobil"} className={type === "mobil" ? "selected" : ""} onClick={() => changeType("mobil")}>Mobil</button>
        <button type="button" aria-pressed={type === "motor"} className={type === "motor" ? "selected" : ""} onClick={() => changeType("motor")}>Motor</button>
      </div>
      <div className="catalog-searchbar"><Search size={20} /><input value={keyword} onChange={(event) => changeKeyword(event.target.value)} placeholder={"Cari nama atau model " + type} aria-label={"Cari " + type} /><span className="search-location"><MapPin size={17} /> {location}</span>{keyword && <button aria-label="Hapus pencarian" type="button" onClick={() => changeKeyword("")}><X size={17} /></button>}</div>
      <div className="filter-row"><div className="filter-chips" role="group" aria-label="Filter kategori kendaraan">{categories.map((item) => <button type="button" className={category === item ? "chip-active" : ""} onClick={() => changeCategory(item)} key={item}>{item}</button>)}</div><span>{filtered.length} {type} tersedia</span></div>
      {catalog.isPending ? <div className="no-results">Memuat katalog...</div> : catalog.isError ? <div className="no-results"><h3>Katalog belum dapat dimuat</h3><p>{catalog.error.message}</p><button className="dark-link" onClick={() => catalog.refetch()}>Coba lagi</button></div> : <div className="car-grid">{pageItems.map((item) => <VehicleCard key={item.id} item={item} active={activeVehicle?.id === item.id} onSelect={() => setSelected(item.id)} />)}</div>}
      {catalog.isSuccess && !filtered.length && <div className="no-results"><Search size={28} /><h3>Kendaraan tidak ditemukan</h3><p>Coba nama lain atau pilih kategori berbeda.</p></div>}
      {filtered.length > 0 && <nav className="catalog-pagination" aria-label="Halaman katalog">
        <span>Menampilkan {(currentPage - 1) * pageSize + 1}–{Math.min(currentPage * pageSize, filtered.length)} dari {filtered.length} {type}</span>
        {pageCount > 1 && <div className="pagination-controls">
          <button type="button" onClick={() => changePage(currentPage - 1)} disabled={currentPage === 1} aria-label="Halaman sebelumnya">‹</button>
          {Array.from({ length: pageCount }, (_, index) => <button key={index} type="button" aria-label={"Halaman " + (index + 1)} aria-current={currentPage === index + 1 ? "page" : undefined} className={currentPage === index + 1 ? "page-active" : ""} onClick={() => changePage(index + 1)}>{index + 1}</button>)}
          <button type="button" onClick={() => changePage(currentPage + 1)} disabled={currentPage === pageCount} aria-label="Halaman berikutnya">›</button>
        </div>}
      </nav>}
    </main>
    {activeVehicle ? <aside className="selection-panel">
      <div className="selection-top"><div className="selection-overline"><span>PILIHAN ANDA</span><span>{String(selectedIndex).padStart(2, "0")} / {String(filtered.length).padStart(2, "0")}</span></div><div className="selection-image" style={{ background: activeVehicle.tint }}><img src={activeVehicle.image} alt={activeVehicle.name} />{activeVehicle.illustrative && <small>Visual ilustrasi</small>}</div><div className="selection-title"><span>{activeVehicle.kind} · {activeVehicle.category}</span><h2>{activeVehicle.name}</h2><p>Periksa pilihan dan lanjutkan ke formulir booking.</p></div></div>
      <div className="selection-dark"><h3>Ringkasan Kendaraan</h3><div className="overview-grid"><span><CarFront size={17} /> {activeVehicle.kind === "mobil" ? "Mobil" : "Motor"}</span><span>{activeVehicle.category}</span></div><div className="panel-rule" /><h3>Rencana Sewa</h3><div className="plan-box"><span><Clock3 size={17} /> Tarif contoh per hari</span><strong>{rupiah(activeVehicle.rate)}</strong></div><div className="pickup-label">Lokasi pengambilan</div><div className="pickup-box"><MapPin size={18} /> {location}</div><div className="selection-bottom"><div><small>Mulai dari</small><strong>{rupiah(activeVehicle.rate)}<span>/hari</span></strong></div>{session.data?.registered ? <Link to="/booking" search={{ car: activeVehicle.id, location, start, end, type }} className="yellow-button">Book Now</Link> : <Link to="/login" search={{ redirect: bookingPath(activeVehicle, location, start, end) }} className="yellow-button">Book Now</Link>}</div></div>
    </aside> : <aside className="selection-panel selection-empty"><Search size={26} /><h2>Belum ada pilihan</h2><p>Coba kategori atau nama kendaraan lain.</p></aside>}
  </Workspace>;
}

type Booking = { id: string; carId: string; vehicleName: string | null; vehicleKind: string | null; vehicleCategory: string | null; vehicleImage: string | null; vehicleTint: string | null; location: string; startDate: string; endDate: string; fullName: string; email: string; phone: string; handover: string; note: string; dailyRate: number; total: number; status: string; paymentProofName: string | null; paymentVerifiedAt: string | null; cancelledAt: string | null; createdAt: string };
function bookedVehicle(booking: Booking, catalog: Vehicle[]): Vehicle {
  const fallback = catalog.find((item) => item.id === booking.carId) ?? findVehicle(booking.carId);
  return booking.vehicleName ? { ...fallback, name: booking.vehicleName, kind: booking.vehicleKind === "motor" ? "motor" : "mobil", category: booking.vehicleCategory || fallback.category, image: booking.vehicleImage || fallback.image, tint: booking.vehicleTint || fallback.tint, rate: booking.dailyRate, illustrative: !booking.vehicleImage?.startsWith("/api/catalog/images/") } : fallback;
}
async function bookingsRequest(): Promise<{ bookings: Booking[] }> {
  const response = await fetch("/api/bookings", { cache: "no-store" });
  const data = await response.json() as { bookings: Booking[]; error?: string };
  if (!response.ok) throw new Error(data.error || "Riwayat tidak dapat dimuat.");
  return data;
}

function BookingPage() {
  const search = useSearch({ strict: false }) as Partial<SearchState>;
  const catalog = useQuery({ queryKey: ["catalog"], queryFn: catalogRequest });
  const vehicle = catalog.data?.vehicles.find((item) => item.id === search.car) ?? (!search.car ? catalog.data?.vehicles[0] : undefined);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const session = useQuery({ queryKey: ["session"], queryFn: sessionRequest });
  const [location, setLocation] = useState(search.location && cities.includes(search.location) ? search.location : "Jakarta");
  const [start, setStart] = useState(search.start || dateInput(1));
  const [end, setEnd] = useState(search.end || dateInput(3));
  const [handover, setHandover] = useState("showroom");
  const [fullName, setFullName] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);
  const [phone, setPhone] = useState<string | null>(null);
  const bookingName = fullName ?? session.data?.user?.fullName ?? "";
  const bookingEmail = email ?? session.data?.user?.email ?? "";
  const bookingPhone = phone ?? session.data?.user?.phone ?? "";
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const days = rentalDays(start, end);
  const returnTo = vehicle ? bookingPath(vehicle, location, start, end) : search.car ? "/booking?" + new URLSearchParams({ car: search.car, location, start, end }).toString() : "/koleksi";
  useEffect(() => {
    if (session.data && !session.data.registered) {
      navigate({ to: session.data.authenticated ? "/register" : "/login", search: { redirect: returnTo }, replace: true });
    }
  }, [navigate, returnTo, session.data]);
  const mutation = useMutation({ mutationFn: async () => {
    if (!vehicle) throw new Error("Kendaraan tidak tersedia.");
    const response = await fetch("/api/bookings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ carId: vehicle.id, location, startDate: start, endDate: end, fullName: bookingName, email: bookingEmail, phone: bookingPhone, handover, note }) });
    const data = await response.json() as { id?: string; error?: string };
    if (!response.ok || !data.id) throw new Error(data.error || "Booking belum tersimpan.");
    return data;
  }, onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: ["bookings"] }); navigate({ to: "/riwayat" }); } });
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (days < 1 || days > 30) { setError("Periode sewa harus antara 1–30 hari."); return; }
    setError(""); mutation.mutate();
  }
  if (session.isError) return <Workspace active="booking"><main className="history-container"><div className="history-message"><h2>Akun belum dapat diperiksa</h2><p>{session.error.message}</p><button className="dark-link" onClick={() => session.refetch()}>Coba Lagi</button></div></main></Workspace>;
  if (!session.data?.registered) return <Workspace active="booking"><main className="history-container"><div className="history-message">Memeriksa akun...</div></main></Workspace>;
  if (catalog.isPending) return <Workspace active="booking"><main className="history-container"><div className="history-message">Memuat kendaraan...</div></main></Workspace>;
  if (catalog.isError) return <Workspace active="booking"><main className="history-container"><div className="history-message"><h2>Katalog belum dapat dimuat</h2><p>{catalog.error.message}</p><button className="dark-link" onClick={() => catalog.refetch()}>Coba Lagi</button></div></main></Workspace>;
  if (!vehicle) return <Workspace active="booking"><main className="history-container"><div className="history-message"><h2>Kendaraan tidak tersedia</h2><p>Pilih kendaraan lain dari katalog untuk melanjutkan booking.</p><Link to="/koleksi" search={{}} className="yellow-button">Lihat Katalog</Link></div></main></Workspace>;
  return <Workspace active="booking"><main className="booking-container"><div className="booking-heading"><span className="eyebrow">RENTALX / BOOKING</span><h1>Complete Your Booking</h1><p>Isi detail perjalanan dan kontak Anda. Kami akan meninjau permintaan sewa ini.</p></div><form onSubmit={submit} className="booking-layout"><div className="booking-form-column"><section className="form-section"><div className="section-title"><span className="step-number">01</span><div><h2>Periode & Pengambilan</h2><p>Tentukan kapan dan di mana kendaraan akan digunakan.</p></div></div><div className="form-grid"><div className="field field-wide"><span>Lokasi pengambilan</span><div className="input-icon"><MapPin size={18} /><CitySelect value={location} onChange={setLocation} /></div></div><label className="field"><span>Tanggal mulai</span><div className="input-icon"><CalendarDays size={18} /><input required type="date" min={dateInput()} value={start} onChange={(event) => setStart(event.target.value)} /></div></label><label className="field"><span>Tanggal selesai</span><div className="input-icon"><CalendarDays size={18} /><input required type="date" min={start} value={end} onChange={(event) => setEnd(event.target.value)} /></div></label></div><div className="handover-group"><span>Metode pengambilan</span><div className="choice-row"><label className={"choice-card " + (handover === "showroom" ? "choice-active" : "")}><input type="radio" name="handover" value="showroom" checked={handover === "showroom"} onChange={() => setHandover("showroom")} /><CarFront size={19} /><strong>Ambil di showroom</strong><small>Datang ke lokasi RentalX</small></label><label className={"choice-card " + (handover === "delivery" ? "choice-active" : "")}><input type="radio" name="handover" value="delivery" checked={handover === "delivery"} onChange={() => setHandover("delivery")} /><MapPin size={19} /><strong>Antar ke lokasi</strong><small>Tim kami menghubungi Anda</small></label></div></div></section><section className="form-section"><div className="section-title"><span className="step-number">02</span><div><h2>Data Penyewa</h2><p>Informasi ini dipakai untuk menghubungi Anda terkait booking.</p></div></div><div className="form-grid"><label className="field field-wide"><span>Nama lengkap</span><div className="input-icon"><UserRound size={18} /><input required autoComplete="name" value={bookingName} maxLength={100} onChange={(event) => setFullName(event.target.value)} placeholder="Nama sesuai identitas" /></div></label><label className="field"><span>Email</span><div className="input-icon"><Mail size={18} /><input required type="email" autoComplete="email" value={bookingEmail} maxLength={150} onChange={(event) => setEmail(event.target.value)} placeholder="nama@email.com" /></div></label><label className="field"><span>Nomor telepon</span><div className="input-icon"><Phone size={18} /><input required type="tel" autoComplete="tel" value={bookingPhone} maxLength={25} onChange={(event) => setPhone(event.target.value)} placeholder="08xxxxxxxxxx" /></div></label><label className="field field-wide"><span>Catatan tambahan <em>(opsional)</em></span><textarea value={note} maxLength={500} onChange={(event) => setNote(event.target.value)} placeholder="Kebutuhan atau pertanyaan untuk tim kami" rows={3} /></label></div></section></div><aside className="booking-summary"><div className="summary-image" style={{ background: vehicle.tint }}><span>PILIHAN {vehicle.kind.toUpperCase()}</span><img src={vehicle.image} alt={"Ilustrasi " + vehicle.kind} /><small>Visual ilustrasi</small></div><div className="summary-content"><span className="eyebrow">{vehicle.category.toUpperCase()}</span><h2>{vehicle.name}</h2><p>Detail kendaraan pilihan Anda.</p><div className="summary-specs"><span><CarFront size={17} /> {vehicle.kind === "mobil" ? "Mobil" : "Motor"}</span><span>{vehicle.category}</span></div><div className="summary-divider" /><dl><div><dt>Tarif contoh</dt><dd>{rupiah(vehicle.rate)} / hari</dd></div><div><dt>Durasi</dt><dd>{days} hari</dd></div><div><dt>Periode</dt><dd>{niceDate(start)} – {niceDate(end)}</dd></div><div><dt>Lokasi</dt><dd>{location}</dd></div></dl><div className="summary-total"><span>Estimasi total</span><strong>{rupiah(vehicle.rate * days)}</strong></div><p className="booking-note"><ShieldCheck size={17} /> Setelah booking, unggah bukti pembayaran di Riwayat. Verifikasi pada situs demo ini berlangsung otomatis.</p>{(error || mutation.error) && <p className="form-error" role="alert">{error || mutation.error?.message}</p>}<button type="submit" className="yellow-button submit-booking" disabled={mutation.isPending || days < 1 || days > 30}>{mutation.isPending ? "Menyimpan booking..." : "Kirim Permintaan Booking"}</button></div></aside></form></main></Workspace>;
}

function PaymentUploader({ booking }: { booking: Booking }) {
  const [file, setFile] = useState<File | null>(null);
  const queryClient = useQueryClient();
  const mutation = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("Pilih bukti pembayaran terlebih dahulu.");
      if (file.size > 5 * 1024 * 1024) throw new Error("Ukuran berkas maksimal 5 MB.");
      const form = new FormData();
      form.set("proof", file);
      const response = await fetch("/api/bookings/" + encodeURIComponent(booking.id) + "/payment", { method: "POST", body: form });
      const data = await response.json() as { verified?: boolean; error?: string };
      if (!response.ok || !data.verified) throw new Error(data.error || "Bukti belum tersimpan.");
    },
    onSuccess: async () => { setFile(null); await queryClient.invalidateQueries({ queryKey: ["bookings"] }); },
  });
  if (booking.paymentVerifiedAt) return <div className="payment-verified"><CheckCircle2 size={19} /><div><strong>Pembayaran terverifikasi</strong><span>Demo: status langsung terverifikasi setelah bukti diunggah.</span></div><a href={"/api/bookings/" + encodeURIComponent(booking.id) + "/payment"} target="_blank" rel="noopener noreferrer">Lihat bukti</a></div>;
  return <div className="payment-upload"><div><strong>Unggah bukti pembayaran</strong><p>PNG, JPG, atau PDF · maksimal 5 MB. Untuk demo, unggahan langsung mengubah status menjadi terverifikasi.</p></div><div className="payment-actions"><label className="payment-file"><UploadCloud size={17} /><span>{file ? file.name : "Pilih berkas"}</span><input type="file" accept=".png,.jpg,.jpeg,.pdf,image/png,image/jpeg,application/pdf" onChange={(event) => setFile(event.target.files?.[0] ?? null)} /></label><button type="button" className="yellow-button" onClick={() => mutation.mutate()} disabled={!file || mutation.isPending}>{mutation.isPending ? "Mengunggah..." : "Upload & Verifikasi"}</button></div>{mutation.error && <p className="form-error" role="alert">{mutation.error.message}</p>}</div>;
}

function CancelBooking({ booking }: { booking: Booking }) {
  const queryClient = useQueryClient();
  const mutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/bookings/" + encodeURIComponent(booking.id) + "/cancel", { method: "PATCH" });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Booking belum dapat dibatalkan.");
    },
    onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: ["bookings"] }); },
  });
  if (booking.status === "Dibatalkan") return <p className="cancelled-note">Booking ini telah dibatalkan.{booking.paymentVerifiedAt && <> Hubungi admin untuk informasi pengembalian dana. <a href={"/api/bookings/" + encodeURIComponent(booking.id) + "/payment"} target="_blank" rel="noopener noreferrer">Lihat bukti pembayaran</a></>}</p>;
  return <div className="cancel-booking"><button type="button" disabled={mutation.isPending} onClick={() => { if (window.confirm("Batalkan booking " + booking.id + "? Tindakan ini tidak dapat diurungkan.")) mutation.mutate(); }}>{mutation.isPending ? "Membatalkan..." : "Batalkan booking"}</button>{mutation.error && <p className="form-error" role="alert">{mutation.error.message}</p>}</div>;
}

function HistoryPage() {
  const session = useQuery({ queryKey: ["session"], queryFn: sessionRequest });
  const navigate = useNavigate();
  useEffect(() => {
    if (session.data && !session.data.registered) navigate({ to: session.data.authenticated ? "/register" : "/login", search: { redirect: "/riwayat" }, replace: true });
  }, [navigate, session.data]);
  const query = useQuery({ queryKey: ["bookings"], queryFn: bookingsRequest, enabled: session.data?.registered === true });
  const catalog = useQuery({ queryKey: ["catalog"], queryFn: catalogRequest });
  const items = query.data?.bookings ?? [];
  if (session.isError) return <Workspace active="history"><main className="history-container"><div className="history-message"><h2>Akun belum dapat diperiksa</h2><p>{session.error.message}</p><button className="dark-link" onClick={() => session.refetch()}>Coba Lagi</button></div></main></Workspace>;
  if (!session.data?.registered) return <Workspace active="history"><main className="history-container"><div className="history-message">Memeriksa akun...</div></main></Workspace>;
  return <Workspace active="history"><main className="history-container">
    <div className="history-intro"><span className="eyebrow">YOUR JOURNEY</span><h1>Tiket & Riwayat Sewa<span>✳</span></h1><p>Lihat kembali booking, unggah bukti pembayaran, dan pantau statusnya.</p></div>
    {query.isPending ? <div className="history-message">Memuat riwayat booking...</div> : query.isError ? <div className="history-message"><h2>Riwayat belum dapat dimuat</h2><p>{query.error.message}</p><button className="dark-link" onClick={() => query.refetch()}>Coba Lagi</button></div> : !items.length ? <div className="history-message empty-history"><span className="empty-icon"><Ticket size={30} /></span><h2>Belum ada booking</h2><p>Kendaraan pilihan Anda menunggu. Mulai dari koleksi dan pilih tanggal perjalanan.</p><Link className="yellow-button" to="/koleksi" search={{}}>Jelajahi Koleksi</Link></div> : <div className="ticket-list">
      <div className="list-heading"><h2>Booking Anda</h2><span>{items.length} permintaan</span></div>
      {items.map((item) => { const vehicle = bookedVehicle(item, catalog.data?.vehicles ?? []); return <article className="ticket-card" key={item.id}>
        <div className="ticket-image" style={{ background: vehicle.tint }}><img src={vehicle.image} alt={vehicle.name} />{vehicle.illustrative && <small>Visual ilustrasi</small>}</div>
        <div className="ticket-content"><div className="ticket-top"><span className="ticket-id"><Ticket size={16} /> {item.id}</span><span className={"status-pill " + (item.status === "Dibatalkan" ? "status-cancelled" : item.paymentVerifiedAt || item.status === "Dikonfirmasi" ? "status-verified" : "")}>{item.status === "Dibatalkan" ? <X size={14} /> : item.paymentVerifiedAt || item.status === "Dikonfirmasi" ? <CheckCircle2 size={14} /> : <Clock3 size={14} />}{item.status}</span></div><h3>{vehicle.name}</h3><p className="ticket-created">Diajukan {new Intl.DateTimeFormat("id-ID", { day: "numeric", month: "long", year: "numeric" }).format(new Date(item.createdAt))}</p><div className="ticket-data"><div><span>PERIODE SEWA</span><strong>{niceDate(item.startDate)} – {niceDate(item.endDate)}</strong></div><div><span>LOKASI</span><strong>{item.location}</strong></div><div><span>PENGAMBILAN</span><strong>{item.handover === "delivery" ? "Diantar ke lokasi" : "Ambil di showroom"}</strong></div><div><span>ESTIMASI TOTAL</span><strong>{rupiah(item.total)}</strong></div></div>{item.status !== "Dibatalkan" && <PaymentUploader booking={item} />}<CancelBooking booking={item} /></div>
      </article>; })}
      <p className="history-footnote"><CheckCircle2 size={16} /> Verifikasi pembayaran pada situs ini otomatis untuk keperluan demo.</p>
    </div>}
  </main></Workspace>;
}

async function adminBookingsRequest(): Promise<{ bookings: Booking[] }> {
  const response = await fetch("/api/admin/bookings", { cache: "no-store" });
  const data = await response.json() as { bookings: Booking[]; error?: string };
  if (!response.ok) throw new Error(data.error || "Booking belum dapat dimuat.");
  return data;
}

function AdminVehicleForm({ initial, onClose }: { initial?: Vehicle; onClose: () => void }) {
  const queryClient = useQueryClient();
  const [name, setName] = useState(initial?.name ?? "");
  const [kind, setKind] = useState<VehicleKind>(initial?.kind ?? "mobil");
  const [category, setCategory] = useState(initial?.category ?? "MPV");
  const [rate, setRate] = useState(String(initial?.rate ?? ""));
  const [image, setImage] = useState(initial?.image ?? "/images/family-car-v2.png");
  const [tint, setTint] = useState(initial?.tint ?? "#f1eee5");
  const [file, setFile] = useState<File | null>(null);
  const mutation = useMutation({
    mutationFn: async () => {
      let imagePath = image;
      if (file) {
        const form = new FormData();
        form.set("image", file);
        const upload = await fetch("/api/admin/catalog/images", { method: "POST", body: form });
        const result = await upload.json() as { image?: string; error?: string };
        if (!upload.ok || !result.image) throw new Error(result.error || "Gambar belum dapat diunggah.");
        imagePath = result.image;
      }
      const response = await fetch("/api/admin/catalog", { method: initial ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: initial?.id, name, kind, category, rate: Number(rate), image: imagePath, tint }) });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw new Error(result.error || "Kendaraan belum dapat disimpan.");
    },
    onSuccess: async () => { await Promise.all([queryClient.invalidateQueries({ queryKey: ["catalog"] }), queryClient.invalidateQueries({ queryKey: ["adminCatalog"] })]); onClose(); },
  });
  function changeKind(value: VehicleKind) {
    setKind(value); setCategory(value === "mobil" ? "MPV" : "Matic");
    if (image === "/images/family-car-v2.png" || image === "/images/city-motor-v2.png") setImage(value === "mobil" ? "/images/family-car-v2.png" : "/images/city-motor-v2.png");
  }
  return <form className="admin-form" onSubmit={(event) => { event.preventDefault(); mutation.mutate(); }}>
    <div className="admin-form-heading"><div><span className="eyebrow">KATALOG</span><h2>{initial ? "Edit kendaraan" : "Tambah kendaraan"}</h2></div><button type="button" className="admin-icon-button" onClick={onClose} aria-label="Tutup formulir"><X size={20} /></button></div>
    <div className="admin-form-grid">
      <label className="admin-field admin-span"><span>Nama kendaraan</span><input required minLength={2} maxLength={100} value={name} onChange={(event) => setName(event.target.value)} placeholder="Contoh: Toyota Avanza" /></label>
      <label className="admin-field"><span>Jenis</span><select value={kind} onChange={(event) => changeKind(event.target.value as VehicleKind)}><option value="mobil">Mobil</option><option value="motor">Motor</option></select></label>
      <label className="admin-field"><span>Kategori</span><select value={category} onChange={(event) => setCategory(event.target.value)}>{(kind === "mobil" ? carCategories : motorCategories).slice(1).map((item) => <option key={item} value={item}>{item}</option>)}</select></label>
      <label className="admin-field"><span>Tarif per hari (Rp)</span><input required type="number" min="10000" max="10000000" step="1000" value={rate} onChange={(event) => setRate(event.target.value)} placeholder="450000" /></label>
      <label className="admin-field"><span>Warna latar gambar</span><input type="color" value={tint} onChange={(event) => setTint(event.target.value)} /></label>
      <label className="admin-field admin-span"><span>Foto kendaraan (opsional)</span><input type="file" accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp" onChange={(event) => setFile(event.target.files?.[0] ?? null)} /><small>PNG, JPG, atau WebP, maksimal 5 MB. Jika kosong, gunakan gambar ilustrasi yang sudah ada.</small></label>
    </div>
    <div className="admin-form-actions"><button className="admin-secondary" type="button" onClick={onClose}>Batal</button><button className="yellow-button" type="submit" disabled={mutation.isPending}>{mutation.isPending ? "Menyimpan..." : initial ? "Simpan Perubahan" : "Tambah Kendaraan"}</button></div>
    {mutation.error && <p className="form-error" role="alert">{mutation.error.message}</p>}
  </form>;
}

function AdminPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const session = useQuery({ queryKey: ["session"], queryFn: sessionRequest });
  const allowed = session.data?.isAdmin === true;
  const catalog = useQuery({ queryKey: ["adminCatalog"], queryFn: async () => {
    const response = await fetch("/api/admin/catalog", { cache: "no-store" });
    const data = await response.json() as { vehicles: Vehicle[]; error?: string };
    if (!response.ok) throw new Error(data.error || "Katalog belum dapat dimuat.");
    return data;
  }, enabled: allowed });
  const bookingsQuery = useQuery({ queryKey: ["adminBookings"], queryFn: adminBookingsRequest, enabled: allowed });
  const [tab, setTab] = useState<"catalog" | "bookings">("catalog");
  const [kind, setKind] = useState<"semua" | VehicleKind>("semua");
  const [term, setTerm] = useState("");
  const [editing, setEditing] = useState<Vehicle | "new" | null>(null);
  const [statusFilter, setStatusFilter] = useState("Semua");
  useEffect(() => { if (session.data && !session.data.authenticated) navigate({ to: "/login", search: { redirect: "/admin" }, replace: true }); }, [navigate, session.data]);
  const remove = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch("/api/admin/catalog", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Kendaraan belum dapat dihapus.");
    },
    onSuccess: async () => { await Promise.all([queryClient.invalidateQueries({ queryKey: ["adminCatalog"] }), queryClient.invalidateQueries({ queryKey: ["catalog"] })]); },
  });
  const confirm = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch("/api/admin/bookings/" + encodeURIComponent(id), { method: "PATCH" });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Booking belum dapat dikonfirmasi.");
    },
    onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: ["adminBookings"] }); },
  });
  const catalogItems = (catalog.data?.vehicles ?? []).filter((item) => (kind === "semua" || item.kind === kind) && item.name.toLowerCase().includes(term.toLowerCase()));
  const bookingItems = (bookingsQuery.data?.bookings ?? []).filter((item) => statusFilter === "Semua" || item.status === statusFilter);
  const waitingCount = (bookingsQuery.data?.bookings ?? []).filter((item) => item.status === "Menunggu konfirmasi" || item.status === "Pembayaran terverifikasi").length;
  if (session.isPending || (session.data && !session.data.authenticated)) return <Workspace active="admin"><main className="history-container"><div className="history-message">Memeriksa akses admin...</div></main></Workspace>;
  if (session.isError) return <Workspace active="admin"><main className="history-container"><div className="history-message"><h2>Akun belum dapat diperiksa</h2><p>{session.error.message}</p><button className="dark-link" onClick={() => session.refetch()}>Coba Lagi</button></div></main></Workspace>;
  if (!allowed) return <Workspace active="admin"><main className="history-container"><div className="history-message"><ShieldCheck size={30} /><h2>Akses admin terbatas</h2><p>Halaman ini hanya tersedia untuk akun admin RentalX.</p><Link to="/koleksi" search={{}} className="yellow-button">Kembali ke Katalog</Link></div></main></Workspace>;
  return <Workspace active="admin"><main className="admin-container">
    <div className="admin-header"><div><span className="eyebrow">RENTALX / ADMIN</span><h1>Kelola RentalX</h1><p>Perbarui katalog dan tindak lanjuti permintaan sewa.</p></div><a className="admin-secondary admin-signout" href="/signout-with-chatgpt?return_to=%2F"><LogOut size={16} /> Keluar</a></div>
    <div className="admin-tabs" role="tablist" aria-label="Bagian admin"><button type="button" role="tab" aria-selected={tab === "catalog"} className={tab === "catalog" ? "selected" : ""} onClick={() => { setTab("catalog"); setEditing(null); }}>Katalog <span>{catalog.data?.vehicles.length ?? 0}</span></button><button type="button" role="tab" aria-selected={tab === "bookings"} className={tab === "bookings" ? "selected" : ""} onClick={() => setTab("bookings")}>Booking <span>{waitingCount} perlu ditinjau</span></button></div>
    {tab === "catalog" ? <section className="admin-section">
      <div className="admin-section-head"><div><h2>Daftar kendaraan</h2><p>Perubahan langsung tampil di katalog publik.</p></div><button type="button" className="yellow-button" onClick={() => setEditing("new")}><Plus size={17} /> Tambah Kendaraan</button></div>
      {editing && <AdminVehicleForm key={editing === "new" ? "new" : editing.id} initial={editing === "new" ? undefined : editing} onClose={() => setEditing(null)} />}
      <div className="admin-toolbar"><input type="search" value={term} onChange={(event) => setTerm(event.target.value)} placeholder="Cari kendaraan..." aria-label="Cari kendaraan" /><select value={kind} onChange={(event) => setKind(event.target.value as typeof kind)} aria-label="Filter jenis"><option value="semua">Semua jenis</option><option value="mobil">Mobil</option><option value="motor">Motor</option></select></div>
      {catalog.isPending ? <div className="admin-empty">Memuat katalog...</div> : catalog.isError ? <div className="admin-empty" role="alert">{catalog.error.message} <button onClick={() => catalog.refetch()}>Coba lagi</button></div> : !catalogItems.length ? <div className="admin-empty">Tidak ada kendaraan yang cocok.</div> : <div className="admin-list">{catalogItems.map((item) => <article className="admin-vehicle-row" key={item.id}><div className="admin-vehicle-image" style={{ background: item.tint }}><img src={item.image} alt="" /></div><div className="admin-vehicle-info"><h3>{item.name}</h3><p>{item.kind === "mobil" ? "Mobil" : "Motor"} · {item.category}</p><strong>{rupiah(item.rate)} / hari</strong></div><div className="admin-row-actions"><button className="admin-secondary" type="button" onClick={() => { setEditing(item); window.scrollTo({ top: 0, behavior: "smooth" }); }}><Pencil size={16} /> Edit</button><button className="admin-danger" type="button" disabled={remove.isPending} onClick={() => { if (window.confirm("Hapus " + item.name + " dari katalog? Riwayat booking tetap tersimpan.")) remove.mutate(item.id); }}><Trash2 size={16} /> Hapus</button></div></article>)}</div>}
      {remove.error && <p className="form-error" role="alert">{remove.error.message}</p>}
    </section> : <section className="admin-section">
      <div className="admin-section-head"><div><h2>Permintaan booking</h2><p>Periksa detail pemesan dan konfirmasi booking yang masuk.</p></div><select className="admin-status-filter" value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} aria-label="Filter status booking">{["Semua", "Menunggu konfirmasi", "Pembayaran terverifikasi", "Dikonfirmasi", "Dibatalkan"].map((value) => <option key={value}>{value}</option>)}</select></div>
      {bookingsQuery.isPending ? <div className="admin-empty">Memuat booking...</div> : bookingsQuery.isError ? <div className="admin-empty" role="alert">{bookingsQuery.error.message} <button onClick={() => bookingsQuery.refetch()}>Coba lagi</button></div> : !bookingItems.length ? <div className="admin-empty">Belum ada booking pada status ini.</div> : <div className="admin-booking-list">{bookingItems.map((item) => { const vehicle = bookedVehicle(item, catalog.data?.vehicles ?? []); return <article className="admin-booking-card" key={item.id}>
        <div className="admin-booking-top"><div><span className="ticket-id"><Ticket size={15} /> {item.id}</span><h3>{vehicle.name}</h3><p>{item.fullName} · {item.email} · {item.phone}</p></div><span className={"status-pill " + (item.status === "Dibatalkan" ? "status-cancelled" : item.status === "Dikonfirmasi" || item.paymentVerifiedAt ? "status-verified" : "")}>{item.status}</span></div>
        <div className="admin-booking-details"><span><small>Periode</small>{niceDate(item.startDate)} – {niceDate(item.endDate)}</span><span><small>Lokasi & pengambilan</small>{item.location} · {item.handover === "delivery" ? "Diantar" : "Showroom"}</span><span><small>Total</small>{rupiah(item.total)}</span><span><small>Pembayaran</small>{item.paymentVerifiedAt ? <>Terverifikasi · <a href={"/api/bookings/" + encodeURIComponent(item.id) + "/payment"} target="_blank" rel="noopener noreferrer">Lihat bukti</a></> : "Belum ada bukti"}</span></div>
        {item.note && <p className="admin-note">Catatan: {item.note}</p>}
        {item.status !== "Dibatalkan" && item.status !== "Dikonfirmasi" && <button type="button" className="yellow-button" disabled={confirm.isPending} onClick={() => confirm.mutate(item.id)}>{confirm.isPending && confirm.variables === item.id ? "Mengonfirmasi..." : "Konfirmasi Booking"}</button>}
      </article>; })}</div>}
      {confirm.error && <p className="form-error" role="alert">{confirm.error.message}</p>}
    </section>}
  </main></Workspace>;
}
