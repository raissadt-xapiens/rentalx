import RentalApp from "./rental-app";
export default function Page() { return <RentalApp />; }
