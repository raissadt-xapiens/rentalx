export type VehicleKind = "mobil" | "motor";
export type Vehicle = {
  id: string;
  name: string;
  kind: VehicleKind;
  category: string;
  rate: number;
  image: string;
  tint: string;
  illustrative?: boolean;
};

export const carCategories = ["Semua", "MPV", "SUV", "City Car & Hatchback", "Sedan", "LCGC", "EV"];
export const motorCategories = ["Semua", "Matic", "Bebek", "Sport", "Trail / Off-Road", "Touring / Adventure"];
export const cities = ["Jakarta", "Bandung", "Surabaya", "Yogyakarta", "Denpasar", "Semarang", "Malang", "Medan", "Makassar", "Bogor"];

type Model = [name: string, rate: number];
const tintByCategory: Record<string, string> = {
  MPV: "#f1eee5", SUV: "#e5eef0", "City Car & Hatchback": "#eef0e8", Sedan: "#e8edf4",
  LCGC: "#f4eee1", EV: "#e4f0ec", Matic: "#f2eddf", Bebek: "#e7eee7", Sport: "#e7edf4",
  "Trail / Off-Road": "#edece5", "Touring / Adventure": "#e6edf0",
};
const slug = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const build = (kind: VehicleKind, category: string, models: Model[]): Vehicle[] => models.map(([name, rate]) => ({
  id: kind + "-" + slug(name), name, kind, category, rate, tint: tintByCategory[category],
  image: kind === "mobil" ? "/images/family-car-v2.png" : "/images/city-motor-v2.png", illustrative: true,
}));

export const vehicles: Vehicle[] = [
  ...build("mobil", "MPV", [["Toyota Avanza", 450000], ["Mitsubishi Xpander", 520000], ["Toyota Innova Zenix", 780000], ["Suzuki Ertiga", 430000], ["Hyundai Stargazer", 480000]]),
  ...build("mobil", "SUV", [["Toyota Fortuner", 1100000], ["Mitsubishi Pajero Sport", 1100000], ["Honda CR-V", 950000], ["Hyundai Creta", 600000], ["Wuling Almaz", 620000]]),
  ...build("mobil", "City Car & Hatchback", [["Honda Brio RS", 420000], ["Toyota Yaris", 500000], ["Suzuki Ignis", 360000], ["Honda City Hatchback", 550000], ["Daihatsu Sirion", 380000]]),
  ...build("mobil", "Sedan", [["Toyota Vios", 550000], ["Honda City", 580000], ["Toyota Corolla Altis", 730000]]),
  ...build("mobil", "LCGC", [["Daihatsu Sigra", 330000], ["Toyota Calya", 340000], ["Honda Brio Satya", 350000], ["Daihatsu Ayla", 280000], ["Toyota Agya", 300000]]),
  ...build("mobil", "EV", [["Wuling Air EV", 580000], ["Hyundai Ioniq 5", 1100000], ["Toyota Innova Zenix Hybrid", 850000], ["BYD Atto 3", 900000], ["Omoda E5", 850000]]),
  ...build("motor", "Matic", [["Honda BeAT", 110000], ["Honda Vario 125/160", 140000], ["Honda Scoopy", 125000], ["Yamaha NMAX", 200000], ["Yamaha Mio M3/Gear", 105000]]),
  ...build("motor", "Bebek", [["Honda Revo", 100000], ["Honda Supra X 125", 120000], ["Yamaha Vega Force", 105000], ["Yamaha Jupiter Z1", 125000], ["Suzuki Satria F150", 165000]]),
  ...build("motor", "Sport", [["Kawasaki Ninja 250/ZX-25R", 350000], ["Honda CBR 150R/250RR", 280000], ["Yamaha R15/R25", 270000], ["Yamaha MT-15/MT-25", 270000], ["Honda CB150R Streetfire", 185000]]),
  ...build("motor", "Trail / Off-Road", [["Kawasaki KLX 150/230", 240000], ["Honda CRF 150L/250L", 250000], ["Yamaha WR155R", 250000], ["Suzuki DR150", 185000], ["Viar Cross X", 170000]]),
  ...build("motor", "Touring / Adventure", [["Honda ADV 160/750", 260000], ["Kawasaki Versys-X 250", 350000], ["Honda CB150X", 215000], ["Suzuki V-Strom 250SX", 290000]]),
];

// Booking lama tetap menampilkan kendaraan asalnya.
const legacyVehicles: Vehicle[] = [
  { id: "mercedes-cla", name: "Mercedes-Benz CLA", kind: "mobil", category: "Sedan", rate: 1850000, image: "/images/mercedes.png", tint: "#f1f0eb" },
  { id: "lamborghini-urus", name: "Lamborghini Urus", kind: "mobil", category: "SUV", rate: 6250000, image: "/images/urus.png", tint: "#fff1ce" },
  { id: "bmw-m3", name: "BMW M3", kind: "mobil", category: "Sedan", rate: 3250000, image: "/images/bmw.png", tint: "#e5f2fc" },
  { id: "cadillac-escalade", name: "Cadillac Escalade", kind: "mobil", category: "SUV", rate: 4850000, image: "/images/cadillac.png", tint: "#e8e8e4" },
];

export const findVehicle = (id?: string) => vehicles.find((vehicle) => vehicle.id === id) ?? legacyVehicles.find((vehicle) => vehicle.id === id) ?? vehicles[0];
export const rupiah = (value: number) => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(value);

export const dateInput = (offset = 0) => {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
};

export const rentalDays = (start: string, end: string) => {
  const a = Date.parse(start + "T00:00:00Z");
  const b = Date.parse(end + "T00:00:00Z");
  return Number.isFinite(a) && Number.isFinite(b) ? Math.max(0, Math.round((b - a) / 86400000)) : 0;
};

export const niceDate = (value: string) => new Intl.DateTimeFormat("id-ID", { day: "numeric", month: "short", year: "numeric" }).format(new Date(value + "T00:00:00"));
