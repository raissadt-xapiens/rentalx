import { getDb } from "../db";
import { catalogChanges } from "../db/schema";
import { vehicles, type Vehicle } from "./cars";

export async function getCatalog(): Promise<Vehicle[]> {
  const changes = await getDb().select().from(catalogChanges);
  const byId = new Map(changes.map((item) => [item.id, item]));
  const original = vehicles.flatMap((item) => {
    const change = byId.get(item.id);
    if (!change) return [item];
    return change.deleted ? [] : [{ ...item, name: change.name, kind: change.kind as Vehicle["kind"], category: change.category, rate: change.rate, image: change.image, tint: change.tint, illustrative: !change.image.startsWith("/api/catalog/images/") }];
  });
  const added = changes.filter((item) => !vehicles.some((vehicle) => vehicle.id === item.id) && !item.deleted).map((item) => ({
    id: item.id, name: item.name, kind: item.kind as Vehicle["kind"], category: item.category, rate: item.rate,
    image: item.image, tint: item.tint, illustrative: !item.image.startsWith("/api/catalog/images/"),
  }));
  return [...original, ...added];
}
