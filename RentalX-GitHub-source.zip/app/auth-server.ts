import { eq } from "drizzle-orm";
import { env } from "cloudflare:workers";
import { getDb } from "../db";
import { profiles } from "../db/schema";

export function platformIdentity(request: Request) {
  const userId = request.headers.get("oai-authenticated-user-id");
  const email = request.headers.get("oai-authenticated-user-email");
  return userId && email ? { userId, email } : null;
}

export function isAdmin(request: Request) {
  const identity = platformIdentity(request);
  const allowed = env.RENTALX_ADMIN_EMAIL?.trim().toLowerCase();
  return Boolean(identity && allowed && identity.email.trim().toLowerCase() === allowed);
}

export function requireAdmin(request: Request) {
  if (!platformIdentity(request)) return noStore({ error: "Silakan masuk sebagai admin." }, 401);
  if (!isAdmin(request)) return noStore({ error: "Akses admin tidak tersedia untuk akun ini." }, 403);
  return null;
}

export async function registeredIdentity(request: Request) {
  const identity = platformIdentity(request);
  if (!identity) return null;
  const profile = await getDb().select().from(profiles).where(eq(profiles.userId, identity.userId)).get();
  return profile ? { ...identity, profile } : null;
}

export function validOrigin(request: Request) {
  const origin = request.headers.get("origin");
  return !origin || origin === new URL(request.url).origin;
}

export function noStore(data: object, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
}
