import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "RentalX | Sewa Mobil & Motor",
  description: "Temukan mobil atau motor, pilih kota dan tanggal sewa, lalu pantau permintaan booking Anda.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id">
      <body className="antialiased">{children}</body>
    </html>
  );
}
