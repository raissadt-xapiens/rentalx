import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const profiles = sqliteTable("profiles", {
  userId: text("user_id").primaryKey(),
  email: text("email").notNull(),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  createdAt: text("created_at").notNull(),
});

export const bookings = sqliteTable("bookings", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  carId: text("car_id").notNull(),
  location: text("location").notNull(),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  handover: text("handover").notNull(),
  note: text("note").notNull().default(""),
  dailyRate: integer("daily_rate").notNull(),
  total: integer("total").notNull(),
  status: text("status").notNull().default("Menunggu konfirmasi"),
  vehicleName: text("vehicle_name"),
  vehicleKind: text("vehicle_kind"),
  vehicleCategory: text("vehicle_category"),
  vehicleImage: text("vehicle_image"),
  vehicleTint: text("vehicle_tint"),
  cancelledAt: text("cancelled_at"),
  paymentProofKey: text("payment_proof_key"),
  paymentProofName: text("payment_proof_name"),
  paymentVerifiedAt: text("payment_verified_at"),
  createdAt: text("created_at").notNull(),
}, (table) => [index("idx_bookings_user_created").on(table.userId, table.createdAt)]);

export const catalogChanges = sqliteTable("catalog_changes", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  kind: text("kind").notNull(),
  category: text("category").notNull(),
  rate: integer("rate").notNull(),
  image: text("image").notNull(),
  tint: text("tint").notNull(),
  deleted: integer("deleted").notNull().default(0),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});
