declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    RENTALX_ADMIN_EMAIL?: string;
  }
}
