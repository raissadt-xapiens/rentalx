# RentalX

Aplikasi sewa mobil dan motor berbasis React, TanStack Router, TanStack Query, Vinext, dan Cloudflare Workers.

**Demo:** [rentalx-transport.raissadsyndt.chatgpt.site](https://rentalx-transport.raissadsyndt.chatgpt.site)

## Fitur

- Homepage dengan pencarian jenis kendaraan, kota, dan tanggal sewa.
- Katalog mobil dan motor dengan kategori, pencarian, pagination, dan ringkasan kendaraan.
- Booking khusus pengguna yang sudah masuk dan mendaftar.
- Riwayat tiket, unggah bukti pembayaran (verifikasi otomatis untuk demo), dan pembatalan booking.
- Panel admin untuk menambah, mengubah, dan menghapus kendaraan beserta fotonya, serta mengonfirmasi booking.
- Tampilan responsif dengan navigasi bawah pada ponsel.

## Teknologi dan data

- React 19, TypeScript, TanStack Router, dan TanStack Query
- Vinext/Cloudflare Workers untuk halaman dan API
- Cloudflare D1 untuk profil, booking, dan perubahan katalog
- Cloudflare R2 untuk gambar katalog dan bukti pembayaran
- Sign in with ChatGPT untuk identitas pengguna; akses admin dibatasi oleh `RENTALX_ADMIN_EMAIL` di lingkungan server

Katalog awal terdapat di `app/cars.ts`. Perubahan admin disimpan di D1, dan detail kendaraan dicatat saat booking agar riwayat tetap utuh walaupun katalog berubah.

## Menjalankan secara lokal

Gunakan Node.js 22.13+ dan pnpm sesuai versi pada `package.json`:

```bash
corepack enable
pnpm install
pnpm build
```

Terapkan migrasi SQL dalam folder `drizzle/` secara berurutan ke D1 lokal, lalu jalankan `pnpm start`. Untuk pengembangan antarmuka, gunakan `pnpm dev`. Konfigurasi binding lokal dan deployment Site ada di `.openai/hosting.json`, `cloudflare-env.d.ts`, serta `dist/server/wrangler.json` setelah build.

Proyek ini memakai autentikasi dan binding dari platform hosting Sites. Mengunggah source ke GitHub saja tidak otomatis menjalankan backend atau menghubungkan database dan penyimpanan. Nilai lingkungan produksi, data D1, dan berkas pengguna di R2 tidak disertakan dalam repo.
